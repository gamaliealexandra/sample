document.getElementById("myButton").onclick= function (){
    var problema_raportata = window.prompt("Ce problema doriti sa raportati?");
    console.log(problema_raportata);

}


         