<?php 

session_start();

	if(!isset($_SESSION['userlogin'])){
		header("Location: login.php");
	}

	if(isset($_GET['logout'])){
		session_destroy();
		unset($_SESSION);
		header("Location: login.php");
	}

?>

<link href ="css/styles.css" rel ="stylesheet">
<!DOCTYPE html>
<html> 
<head>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
    <style>
        #map {position: absolute; top: 0px;; bottom: 0px;; left:900px; right:0px;}
    </style>
</head>
<h1 class="title">
Harta- Bucuresti
</h1>
<body class="body_style">
    <div id="map"></div>
    <div class="box">
      <p class="paragraf">
        Sector 1	99,88	- MEDIU
        <br>
        Sector 2	95.75	- MEDIU
        <br>
        Sector 3	132.07 - RIDICAT
        <br>
        Sector 4	90.26 -	MEDIU
        <br>
        Sector 5	71.35 - SCĂZUT
        <br>
        Sector 6	109.65 -	RIDICAT
        <br>
      </p>
    </div>
    <label class="title2"> Raportati o problema: </label><br>
    <input class="title2" type="text" id="myText"><br>
    <button class="title2" type="button" id="myButton">submit</button>
    <script src="crimemap.js"></script>
    <script>
        var map= L.map('map').setView([44.439, 26.096],13);
        L.tileLayer('https://api.maptiler.com/maps/streets/{z}/{x}/{y}.png?key=523K4y4OsaSqtTpkxFnu', {
            attribution:'<a href="https://www.maptiler.com/copyright/" target="_blank">&copy; MapTiler</a> <a href="https://www.openstreetmap.org/copyright" target="_blank">&copy; OpenStreetMap contributors</a>',

    }).addTo(map)

    map.on('click', 
					function(e){
						var coord = e.latlng.toString().split(',');
						var lat = coord[0].split('(');
						var lng = coord[1].split(')');
						console.log("Latitudine " + lat[1] + " si longitudine: " + lng[0]);
					});
        
      function onLocationFound(e) {
        var radius = e.accuracy / 2;

        L.marker(e.latlng).addTo(map)
            .bindPopup("Esti la  " + radius + " metrii de acest punct").openPopup();

        L.circle(e.latlng, radius).addTo(map);
    }

    function onLocationError(e) {
        alert(e.message);
    }

    map.on('locationfound', onLocationFound);
    map.on('locationerror', onLocationError);

    map.locate({setView: true, maxZoom: 16});
  var marker= L.marker([44.4490378, 26.0935458], {
    title: "sectie1",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 1 </h1> <p> Telefon: 021 316 5684 </p>")
  .openPopup();
  
  var marker= L.marker([44.4908958, 26.0894987], {
    title: "sectie2",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 2 </h1> <p> Telefon: 021 222 9601 </p>")
  .openPopup();

  var marker= L.marker([44.4414225, 26.0882488], {
    title: "sectie3",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 3 </h1> <p> Telefon:  021 313 8902 </p>")
  .openPopup();

  var marker= L.marker([44.4558213, 26.0729851], {
    title: "sectie4",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 4 </h1> <p> Telefon:  021 222 4158 </p>")
  .openPopup();

  var marker= L.marker([44.4821028, 26.0424306], {
    title: "sectie5",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 5 </h1> <p> Telefon:  021 667 5698 </p>")
  .openPopup();

  var marker= L.marker([44.4516379, 26.1046255], {
    title: "sectie6",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 6 </h1> <p> Telefon:  021 210 4335 </p>")
  .openPopup();

  var marker= L.marker([44.4573858, 26.1287050], {
    title: "sectie7",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 7 </h1> <p> Telefon: 021 242 2644 </p>")
  .openPopup();

  var marker= L.marker([44.4386630, 26.1357350], {
    title: "sectie8",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 9 </h1> <p> Telefon: 021 316 6979 </p>")
  .openPopup();

  var marker= L.marker([44.4421972, 26.1642322], {
    title: "sectie9",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 9 </h1> <p> Telefon: 021 255 2433 </p>")
  .openPopup();

  var marker= L.marker([44.4296567, 26.1210706], {
    title: "sectie10",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 10 </h1> <p> Telefon: 021 313 6945 </p>")
  .openPopup();

  var marker= L.marker([44.4214194, 26.1257002], {
    title: "sectie11",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 11 </h1> <p> Telefon: 021 321 7212 </p>")
  .openPopup();

  var marker= L.marker([44.4284825, 26.1406359], {
    title: "sectie12",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 12 </h1> <p> Telefon: 021 311 2021 </p>")
  .openPopup();

  var marker= L.marker([44.4284825, 26.1406359], {
    title: "sectie12",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 12 </h1> <p> Telefon: 021 311 2021 </p>")
  .openPopup();

  var marker= L.marker([44.4159866, 26.1761439], {
    title: "sectie13",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 13 </h1> <p> Telefon: 021 345 0790 </p>")
  .openPopup();

  var marker= L.marker([44.4267290, 26.1992008], {
    title: "sectie23",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 23 </h1> <p> Telefon: 021 315 3534 </p>")
  .openPopup();

  var marker= L.marker([44.4544932, 26.1988257], {
    title: "sectie14",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 14 </h1> <p> Telefon: 021 315 3534 </p>")
  .openPopup();

  var marker= L.marker([44.3873742, 26.1190904], {
    title: "sectie15",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 15 </h1> <p> Telefon: 021 461 0071 </p>")
  .openPopup();

  var marker= L.marker([44.3939346, 26.0976478], {
    title: "sectie16",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 16 </h1> <p> Telefon: 021 332 4434 </p>")
  .openPopup();

  var marker= L.marker([44.3706255, 26.1396886], {
    title: "sectie26",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 26 </h1> <p> Telefon: 021 682 5035 </p>")
  .openPopup();

  var marker= L.marker([44.4336493, 26.0704682], {
    title: "sectie17",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 17 </h1> <p> Telefon: 021 410 9002 </p>")
  .openPopup();

  var marker= L.marker([44.4165233, 26.0871765], {
    title: "sectie18",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 18 </h1> <p> Telefon: 021 315 3534 </p>")
  .openPopup();

  var marker= L.marker([44.3751802, 26.1515621], {
    title: "sectie19",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 19 </h1> <p> Telefon: 021 423 3891 </p>")
  .openPopup();

  var marker= L.marker([44.3962743, 26.0926857], {
    title: "sectie24",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 24 </h1> <p> Telefon: 021 332 4903 </p>")
  .openPopup();

  var marker= L.marker([44.4527073, 26.0504494], {
    title: "sectie20",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 20 </h1> <p> Telefon: 021 221 4055 </p>")
  .openPopup();

  var marker= L.marker([44.4367144, 26.0214623], {
    title: "sectie21",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 21 </h1> <p> Telefon: 021 434 0188 </p>")
  .openPopup();

  var marker= L.marker([44.4237172, 26.0364943], {
    title: "sectie22",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 22 </h1> <p> Telefon: 021 413 1020 </p>")
  .openPopup();

  var marker= L.marker([44.4142629, 26.0236183], {
    title: "sectie25",
  })
  .addTo(map)
  .bindPopup("<h1> Sectia 25 </h1> <p> Telefon: 021 444 1906 </p>")
  .openPopup();

  </script>
</body>
</html>


<a href="index.php?logout=true">Logout</a>